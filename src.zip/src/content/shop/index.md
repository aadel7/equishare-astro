---
title: "Tienda"
page_title: "Kits de actividades científicas"

# our_product
our_product:
  - title: Slime
    slug: "slime"  # add unique slug
    description: Slime.
    image: "/images/product-1.jpg"
    price: 49
    button_list:
      label: Check Details
      link: ""
      enable: false
    button_product:
      label: Comprar
      link: ""
      enable: true
  - title: Agua viajera
    slug: "agua-viajera"  # add unique slug
    description: Agua viajera.
    image: "/images/product-2.jpg"
    price: 49
    button:
      label: Check Details
      link: ""
      enable: false
    button_product:
      label: Comprar
      link: ""
      enable: true
  - title: Mata bacterias
    slug: "mata-bacterias"  # add unique slug
    description: Jabon de manos y pimienta
    price: 49
    image: "/images/product-3.jpg"
    button:
      label: Check Details
      link: ""
      enable: false
    button_product:
      label: Comprar
      link: ""
      enable: true
---
Ofrecemos 10 kits de actividades científicas para realizar en de manera privada o pública en
colaboración con hospitales.
