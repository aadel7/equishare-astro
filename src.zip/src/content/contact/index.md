---
title: Contacto
page_title: Colabora con Equishare!
intro: >
  Si te interesa colaborar con nosotros como voluntario para acercar ciencia a pacientes pediátricos o te interesa traer esta actividad a tu hospital. Por favor mandanos un email indicando si eres voluntario o personal sanitario junto con una breve descripción de tus preferencias/objetivos y nos pondremos en contacto contigo.

---
